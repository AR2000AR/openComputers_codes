---@class udpLib
local udp = {
    UDPLayer = require("network.udp.UDPLayer"),
    UDPDatagram = require("network.udp.UDPDatagram")
}
return udp
