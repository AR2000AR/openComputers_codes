local yaowbglWidget = {
    Widget = require('yaowbgl.widget.Widget'),
    Rectangle = require('yaowbgl.widget.Rectangle'),
    Frame = require('yaowbgl.widget.Frame'),
    Text = require("yaowbgl.widget.Text"),
    Image = require("yaowbgl.widget.Image"),
    TextInput = require("yaowbgl.widget.TextInput"),
    LinkedWidget = require("yaowbgl.widget.LinkedWidget"),
    WidgetList = require("yaowbgl.widget.WidgetList")
}

return yaowbglWidget
