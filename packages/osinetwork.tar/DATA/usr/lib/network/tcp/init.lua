---@class tcpLib
return {
    TCPLayer = require("network.tcp.TCPLayer"),
    TCPSegment = require("network.tcp.TCPSegment")
}
