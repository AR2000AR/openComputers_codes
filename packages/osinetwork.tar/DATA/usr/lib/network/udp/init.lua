---@class udpLib
local udp = {
    UDPLayer = require("network.udp.UDPLayer"),
    --UDPSocket = require("network.udp.UDPSocket"),
}
return udp
